interface Stack {
    void push(int element);
    int pop();
    boolean isEmpty();
    int size();
}